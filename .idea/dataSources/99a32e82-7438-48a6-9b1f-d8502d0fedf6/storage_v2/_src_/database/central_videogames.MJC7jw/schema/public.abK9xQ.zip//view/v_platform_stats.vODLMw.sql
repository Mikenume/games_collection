create view v_platform_stats
            (platform_id, platform, abbreviation, manufacturer, release_year, catalogued, owned, wishlist) as
SELECT p.id                                   AS platform_id,
       p.name                                 AS platform,
       p.abbreviation,
       p.manufacturer,
       p.release_year,
       count(e.id)                            AS catalogued,
       count(e.id) FILTER (WHERE e.owned)     AS owned,
       count(e.id) FILTER (WHERE NOT e.owned) AS wishlist
FROM platforms p
         LEFT JOIN editions e ON e.platform_id = p.id
GROUP BY p.id;

alter table v_platform_stats
    owner to postgres;

