create view v_catalog
            (edition_id, game_id, title, original_year, platform_year, developer, publisher, synopsis, platform,
             abbreviation, manufacturer, region, format, owned, notes, created_at, genres)
as
SELECT e.id                                                               AS edition_id,
       g.id                                                               AS game_id,
       g.title,
       g.release_year                                                     AS original_year,
       e.release_year                                                     AS platform_year,
       g.developer,
       g.publisher,
       g.synopsis,
       p.name                                                             AS platform,
       p.abbreviation,
       p.manufacturer,
       e.region,
       e.format,
       e.owned,
       e.notes,
       g.created_at,
       array_remove(array_agg(DISTINCT gn.name), NULL::character varying) AS genres
FROM editions e
         JOIN games g ON g.id = e.game_id
         JOIN platforms p ON p.id = e.platform_id
         LEFT JOIN game_genres gg ON gg.game_id = g.id
         LEFT JOIN genres gn ON gn.id = gg.genre_id
GROUP BY e.id, g.id, p.id;

alter table v_catalog
    owner to postgres;

