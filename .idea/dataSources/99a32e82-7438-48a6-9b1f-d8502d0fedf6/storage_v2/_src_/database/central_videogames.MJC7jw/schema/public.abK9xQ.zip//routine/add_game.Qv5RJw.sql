create function add_game(p_title text, p_release_year integer, p_developer text, p_publisher text, p_platform text, p_region text DEFAULT 'PAL'::text, p_format text DEFAULT NULL::text, p_genres text[] DEFAULT '{}'::text[], p_synopsis text DEFAULT NULL::text, p_platform_year integer DEFAULT NULL::integer, p_owned boolean DEFAULT true, p_port_developer text DEFAULT NULL::text) returns integer
    language plpgsql
as
$$
DECLARE
    v_game_id     int;
    v_platform_id int;
    v_unknown     text[];
BEGIN
    SELECT id INTO v_platform_id
    FROM platforms
    WHERE abbreviation = p_platform OR name = p_platform;

    IF v_platform_id IS NULL THEN
        RAISE EXCEPTION 'Unknown platform: %', p_platform
            USING HINT = 'Check platforms.abbreviation (PS1, PS2, GBC, GBA, NDS, 3DS, NSW...)';
    END IF;

    SELECT ARRAY_AGG(x) INTO v_unknown
    FROM UNNEST(p_genres) AS x
    WHERE NOT EXISTS (SELECT 1 FROM genres WHERE name = x);

    IF v_unknown IS NOT NULL THEN
        RAISE EXCEPTION 'Unknown genre(s): %', ARRAY_TO_STRING(v_unknown, ', ')
            USING HINT = 'Insert them into genres first, or fix the spelling (accents count).';
    END IF;

    SELECT id INTO v_game_id
    FROM games
    WHERE lower(title) = lower(p_title)
      AND release_year IS NOT DISTINCT FROM p_release_year;

    IF v_game_id IS NULL THEN
        INSERT INTO games (title, release_year, developer, publisher, synopsis)
        VALUES (p_title, p_release_year, p_developer, p_publisher, p_synopsis)
        RETURNING id INTO v_game_id;
    END IF;

    INSERT INTO editions (game_id, platform_id, release_year, region, format, owned, port_developer)
    VALUES (v_game_id, v_platform_id,
            COALESCE(p_platform_year, p_release_year),
            p_region, p_format, p_owned, p_port_developer)
    ON CONFLICT ON CONSTRAINT uq_editions DO NOTHING;

    INSERT INTO game_genres (game_id, genre_id)
    SELECT v_game_id, g.id
    FROM genres g
    WHERE g.name = ANY(p_genres)
    ON CONFLICT DO NOTHING;

    RETURN v_game_id;
END;
$$;

alter function add_game(text, integer, text, text, text, text, text, text[], text, integer, boolean, text) owner to postgres;

