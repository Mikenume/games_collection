create view v_games
            (id, title, release_year, developer, publisher, synopsis, created_at, platforms, genres, edition_count,
             owned_anywhere) as
SELECT g.id,
       g.title,
       g.release_year,
       g.developer,
       g.publisher,
       g.synopsis,
       g.created_at,
       array_remove(array_agg(DISTINCT p.abbreviation), NULL::character varying) AS platforms,
       array_remove(array_agg(DISTINCT gn.name), NULL::character varying)        AS genres,
       count(DISTINCT e.id)                                                      AS edition_count,
       COALESCE(bool_or(e.owned), false)                                         AS owned_anywhere
FROM games g
         LEFT JOIN editions e ON e.game_id = g.id
         LEFT JOIN platforms p ON p.id = e.platform_id
         LEFT JOIN game_genres gg ON gg.game_id = g.id
         LEFT JOIN genres gn ON gn.id = gg.genre_id
GROUP BY g.id;

alter table v_games
    owner to postgres;

